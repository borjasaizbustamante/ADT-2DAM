/**
 * 
 */
/**
 * 
 */
module a {
	requires java.desktop;
}