package mvc.modelo;

/**
 * El Modelo tiene como única responsabilidad acceder a la Bases de Datos
 */
public class Estudiante {

	private String nombre;
	private String id;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}