package mvc.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import mvc.modelo.Estudiante;
import mvc.vista.Vista;

/**
 * El Controlador tiene como única responsabilidad decir qué hacer cuando la
 * interfaz le da una orden, y enviarle una respuesta.
 */
public class Controlador {

	private Estudiante modelo;
	private Vista vista;

	public Controlador(Estudiante modelo, Vista vista) {
		this.modelo = modelo;
		this.vista = vista;

		// Escuchador del evento del botón
		this.vista.addSubmitListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				// ¿Qué hago cuando le dan al botón?
				updateStudent();

				// Accedo al Modelo, lo cargo de información, y actualizo la vista
			}
		});
	}

	private void updateStudent() {
		modelo.setNombre(vista.getNombre());
		modelo.setId(vista.getId());
		vista.setOutput("Nombre: " + modelo.getNombre() + "\nID: " + modelo.getId());
	}
}