package mvc;

import mvc.controlador.Controlador;
import mvc.modelo.Estudiante;
import mvc.vista.Vista;

/**
 * Un ejemplo funcional de MCV (básico, muy básico)
 */
public class McvMainLauncherClass {

	public static void main(String[] args) {
		// Crear el modelo
		Estudiante modelo = new Estudiante();

		// Crear la vista
		Vista vista = new Vista();

		// Crear el controlador
		new Controlador(modelo, vista);
	}
}
