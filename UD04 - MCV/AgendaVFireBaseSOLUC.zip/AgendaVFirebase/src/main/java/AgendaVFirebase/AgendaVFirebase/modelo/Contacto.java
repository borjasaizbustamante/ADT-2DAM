package AgendaVFirebase.AgendaVFirebase.modelo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;

import AgendaVFirebase.AgendaVFirebase.conexion.Conexion;

public class Contacto {

	private String idContacto;
	private String nombre;
	private double telefono;
	private String email;

	private static String collectionName = "contactos";
	private static String fieldNombre = "nombre";
	private static String fieldTelefono = "telefono";
	private static String fieldEmail = "email";

	public Contacto() {
	}

	public Contacto(String pNombre, double pTelefono, String pEmail) {
		this.nombre = pNombre;
		this.telefono = pTelefono;
		this.email = pEmail;
	}

	public String getIdContacto() {
		return idContacto;
	}

	public void setIdContacto(String idContacto) {
		this.idContacto = idContacto;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getTelefono() {
		return telefono;
	}

	public void setTelefono(double telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean mInsertarContacto() {
		boolean registrar = false;

		Firestore con;
		try {
			con = Conexion.conectar();

			CollectionReference contacto = con.collection(collectionName);

			Map<String, Object> contactNew = new HashMap<>();
			contactNew.put(fieldNombre, nombre);
			contactNew.put(fieldTelefono, telefono);
			contactNew.put(fieldEmail, email);
			DocumentReference depNew = contacto.document();

			depNew.set(contactNew);
			registrar = true;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return registrar;
	}

	public boolean mActualizarContacto() {

		boolean actualizar = false;

		try {
			Firestore connect = Conexion.conectar();

			DocumentSnapshot contacto = connect.collection(collectionName).document(String.valueOf(idContacto)).get()
					.get();
			DocumentReference contacRef = contacto.getReference();
			Map<String, Object> contactoNew = contacto.getData();
			contactoNew.put(fieldNombre, nombre);
			contactoNew.put(fieldTelefono, telefono);
			contactoNew.put(fieldEmail, email);
			contacRef.update(contactoNew);

			actualizar = true;
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}

		return actualizar;
	}

	public boolean mEliminarContacto() {
		Firestore co = null;

		boolean eliminar = false;
		try {
			co = Conexion.conectar();

			DocumentSnapshot contacto = co.collection(collectionName).document(String.valueOf(idContacto)).get().get();
			DocumentReference contacRef = contacto.getReference();

			contacRef.delete();
			eliminar = true;

		} catch (InterruptedException | ExecutionException e) {
			System.out.println("Error: Clase Contacto, m�todo mObtenerContactos");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return eliminar;
	}

	public Contacto mObtenerContacto(int idContacto) {
		Firestore co = null;

		try {
			co = Conexion.conectar();

			DocumentSnapshot contacto = co.collection(collectionName).document(String.valueOf(idContacto)).get().get();

			setIdContacto(contacto.getId());
			setNombre(contacto.getString(fieldNombre));
			setTelefono(contacto.getDouble(fieldTelefono));
			setEmail(contacto.getString(fieldEmail));

		} catch (InterruptedException | ExecutionException e) {
			System.out.println("Error: Clase Contacto, metodo mObtenerContactos");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return this;
	}

	public ArrayList<Contacto> mObtenerContactos() {
		Firestore co = null;

		ArrayList<Contacto> listaContactos = new ArrayList<Contacto>();

		try {
			co = Conexion.conectar();

			ApiFuture<QuerySnapshot> query = co.collection(collectionName).get();

			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> contactos = querySnapshot.getDocuments();
			for (QueryDocumentSnapshot contacto : contactos) {

				Contacto c = new Contacto();
				c.setIdContacto(contacto.getId());
				c.setNombre(contacto.getString(fieldNombre));
				c.setTelefono(contacto.getDouble(fieldTelefono));
				c.setEmail(contacto.getString(fieldEmail));
				listaContactos.add(c);
			}

		} catch (InterruptedException | ExecutionException e) {
			System.out.println("Error: Clase Contacto, metodo mObtenerContactos");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return listaContactos;
	}
}
