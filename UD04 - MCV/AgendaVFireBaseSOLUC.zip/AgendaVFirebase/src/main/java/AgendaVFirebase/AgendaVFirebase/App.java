package AgendaVFirebase.AgendaVFirebase;

import AgendaVFirebase.AgendaVFirebase.controlador.ControladorContacto;
import AgendaVFirebase.AgendaVFirebase.vista.Principal;

public class App {
	
	public static void main(String[] args) {
		try {
			Principal ventanaPrincipal = new Principal();
			ventanaPrincipal.setVisible(true);
			
			new ControladorContacto(ventanaPrincipal);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
