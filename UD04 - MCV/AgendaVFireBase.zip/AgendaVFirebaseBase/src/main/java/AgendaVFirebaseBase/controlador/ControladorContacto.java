package AgendaVFirebaseBase.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import AgendaVFirebaseBase.modelo.Contacto;
import AgendaVFirebaseBase.vista.Principal;

public class ControladorContacto implements ActionListener, ListSelectionListener {

	private Principal vistaPrincipal;

	public ControladorContacto(Principal vistaPrincipal) {
		this.vistaPrincipal = vistaPrincipal;

		this.inicializarControlador();

	}

	private void inicializarControlador() {

		this.vistaPrincipal.getBtnConsultarContactos().addActionListener(this);
		this.vistaPrincipal.getBtnConsultarContactos()
				.setActionCommand(Principal.enumAcciones.CARGAR_PANEL_CONSULTA.toString());

		this.vistaPrincipal.getBtnInsertarContacto().addActionListener(this);
		this.vistaPrincipal.getBtnInsertarContacto()
				.setActionCommand(Principal.enumAcciones.CARGAR_PANEL_INSERTAR.toString());

		this.vistaPrincipal.getBtnModificarContacto().addActionListener(this);
		this.vistaPrincipal.getBtnModificarContacto()
				.setActionCommand(Principal.enumAcciones.CARGAR_PANEL_MODIFICAR.toString());

		this.vistaPrincipal.getBtnEliminarContacto().addActionListener(this);
		this.vistaPrincipal.getBtnEliminarContacto()
				.setActionCommand(Principal.enumAcciones.CARGAR_PANEL_ELIMINAR.toString());

		// Acciones del panel Insertar

		// Acciones del panel Modificar

		// Acciones del panel Eliminar
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		Principal.enumAcciones accion = Principal.enumAcciones.valueOf(e.getActionCommand());

		switch (accion) {
		case CARGAR_PANEL_CONSULTA:
			this.vistaPrincipal.mVisualizarPaneles(Principal.enumAcciones.CARGAR_PANEL_CONSULTA);
			this.mCargarContactos(accion);
			break;
		case CARGAR_PANEL_INSERTAR:
			this.vistaPrincipal.mVisualizarPaneles(Principal.enumAcciones.CARGAR_PANEL_INSERTAR);
			this.mCargarContactos(accion);
			break;
		case CARGAR_PANEL_MODIFICAR:
			this.vistaPrincipal.mVisualizarPaneles(Principal.enumAcciones.CARGAR_PANEL_MODIFICAR);
			this.mCargarContactos(accion);
			break;
		case CARGAR_PANEL_ELIMINAR:
			this.vistaPrincipal.mVisualizarPaneles(Principal.enumAcciones.CARGAR_PANEL_ELIMINAR);
			this.mCargarContactos(accion);
			break;
		}
	}

	private void mCargarContactos(Principal.enumAcciones accion) {

		Contacto contactos = new Contacto();

		mLimpiarTabla(accion);

		ArrayList<Contacto> listaContactos = contactos.mObtenerContactos();

		String matrizInfo[][] = new String[listaContactos.size()][4];

		for (int i = 0; i < listaContactos.size(); i++) {
			matrizInfo[i][0] = listaContactos.get(i).getIdContacto();
			matrizInfo[i][1] = listaContactos.get(i).getNombre();
			matrizInfo[i][2] = String.valueOf(listaContactos.get(i).getTelefono());
			matrizInfo[i][3] = listaContactos.get(i).getEmail();

			switch (accion) {
			case CARGAR_PANEL_CONSULTA:
				this.vistaPrincipal.getPanelConsultar().getDefaultTableModel().addRow(matrizInfo[i]);
				break;
			}
		}
	}

	private void mLimpiarTabla(Principal.enumAcciones accion) {
		switch (accion) {
		case CARGAR_PANEL_CONSULTA:
			if (this.vistaPrincipal.getPanelConsultar().getDefaultTableModel().getRowCount() > 0) {
				this.vistaPrincipal.getPanelConsultar().getDefaultTableModel().setRowCount(0);
			}
			break;
		}
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Cambiar valor");
	}
}