package AgendaVFirebaseBase;

import AgendaVFirebaseBase.controlador.ControladorContacto;
import AgendaVFirebaseBase.vista.Principal;

public class App {
	
	public static void main(String[] args) {
		try {
			Principal ventanaPrincipal = new Principal();
			ventanaPrincipal.setVisible(true);
			
			new ControladorContacto(ventanaPrincipal);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
