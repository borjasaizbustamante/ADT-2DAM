package AppTiempo.AppTiempo.vista;

import javax.swing.JFrame;

public class VentanaTiempo extends JFrame {

	private static final long serialVersionUID = 1L;

	public VentanaTiempo() {
		inicializar ();
	}

	private void inicializar() {
		
	}
}
