package genericServerSocket.controller.handlers;

import java.net.Socket;

/**
 * Defines how handlers are
 */
public interface MessageHandler<T> {
	
	public void handle(T message, Socket client) throws Exception;
	
}