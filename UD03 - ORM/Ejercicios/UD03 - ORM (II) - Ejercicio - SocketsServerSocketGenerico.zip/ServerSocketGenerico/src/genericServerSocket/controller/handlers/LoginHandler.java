package genericServerSocket.controller.handlers;

import java.io.ObjectOutputStream;
import java.net.Socket;

import genericServerSocket.controller.messages.AnswerMessage;
import genericServerSocket.controller.messages.LoginMessage;
import genericServerSocket.dataBase.dao.EmployeeDao;

/**
 * Defines what to do when a LoginMessage arrives (handles it)
 */
public class LoginHandler implements MessageHandler<LoginMessage> {

	@Override
	public void handle(LoginMessage message, Socket cliente) throws Exception {

		try {
			System.out.println(message.getUser() + " is trying to log in");

			// This DDBB access would be better with a Simple Factory implemented
			// To separate layers (MCV)
			EmployeeDao employeeDao = new EmployeeDao();
			boolean ok = employeeDao.login(message.getUser(), message.getPass());

			// We get ready to answer the client
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(cliente.getOutputStream());
			
			AnswerMessage answerMessage = new AnswerMessage();
			if (ok) {
				System.out.println("Login ok!");
				answerMessage.setText("Login ok!");
			} else {
				System.out.println("Login error!");
				answerMessage.setText("Login error!");
			}
			
			// We send the answer
			objectOutputStream.writeObject(answerMessage);
			objectOutputStream.flush();
		} catch (Exception e) {
			System.out.println("Error - " + e.getMessage());
		}
	}
}
