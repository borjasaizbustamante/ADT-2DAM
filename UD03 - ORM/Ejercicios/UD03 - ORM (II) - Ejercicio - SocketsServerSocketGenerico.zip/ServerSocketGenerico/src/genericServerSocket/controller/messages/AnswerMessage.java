package genericServerSocket.controller.messages;

/**
 * Defines a Login Message
 */
public class AnswerMessage implements Message {

	private static final long serialVersionUID = -5717429713560585584L;

	private static final String TYPE = "answerMessage";
	
    private String text;

	@Override
	public String getType() {
		return TYPE;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}

