package genericServerSocket.controller.messages;

import java.io.Serializable;

/**
 * Defines how messages are
 */
public interface Message extends Serializable {
	
	public String getType();
	
}