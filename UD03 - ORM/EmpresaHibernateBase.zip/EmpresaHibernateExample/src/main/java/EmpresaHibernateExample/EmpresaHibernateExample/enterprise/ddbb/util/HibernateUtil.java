package EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.util;

/**
 * clase auxiliar que:
 * 
 * <ol>
 * <li>Carga el archivo hibernate.cfg.xml</li>
 * <li>Crea y gestiona el SessionFactory</li>
 * <li>Da acceso a Session</li>
 * </ol>
 */
public class HibernateUtil {

}
