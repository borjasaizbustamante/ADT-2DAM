package EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class Empresa implements Serializable {

	private static final long serialVersionUID = -3524637996993798378L;

	private int id = 0;
	private String nombre = null;
	private String localizacion = null;

	private List<Empleado> empleados;

	public Empresa() {
	}

	public Empresa(String nombre, String localizacion) {
		super();
		this.nombre = nombre;
		this.localizacion = localizacion;
	}

	public Empresa(String nombre, String localizacion, List<Empleado> empleados) {
		super();
		this.nombre = nombre;
		this.localizacion = localizacion;
		this.empleados = empleados;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getLocalizacion() {
		return localizacion;
	}

	public void setLocalizacion(String localizacion) {
		this.localizacion = localizacion;
	}

	public List<Empleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(empleados, id, localizacion, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empresa other = (Empresa) obj;
		return Objects.equals(empleados, other.empleados) && Objects.equals(id, other.id)
				&& Objects.equals(localizacion, other.localizacion) && Objects.equals(nombre, other.nombre);
	}

	@Override
	public String toString() {
		return "Empresa [id=" + id + ", nombre=" + nombre + ", localizacion=" + localizacion  + "]";
	}

}
