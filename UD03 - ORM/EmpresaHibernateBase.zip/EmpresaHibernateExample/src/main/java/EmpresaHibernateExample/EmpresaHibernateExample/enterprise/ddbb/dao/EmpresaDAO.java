package EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.dao;

import java.util.List;

import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.entity.Empresa;

public class EmpresaDAO implements DaoInterface<Empresa> {

	@Override
	public List<Empresa> getAll() {
		List<Empresa> ret = null;
		
		return ret;
	}

	@Override
	public Empresa get(int id) {
		Empresa ret = null;

		return ret;
	}

	@Override
	public void insert(Empresa empresa) {

	}

	@Override
	public void updateDetached(Empresa empresa) {

	}

	@Override
	public void updatePersistent(int id, String name) {

	}

	@Override
	public void deleteDetached(Empresa empresa) {

	}

	@Override
	public void deletePersistent(int id) {

	}

}
