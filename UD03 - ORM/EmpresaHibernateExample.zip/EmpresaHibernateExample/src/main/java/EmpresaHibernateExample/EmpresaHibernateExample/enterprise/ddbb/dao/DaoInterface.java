package EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.dao;

import java.util.List;

public interface DaoInterface <I>{

	public List <I> getAll ();
	
	public I get (int id);
	
	public void insert (I i);
	
	public void updateDetached (I i);
	
	public void updatePersistent(int id, String name);
	
	public void deleteDetached (I i);
	
	public void deletePersistent(int id);
}
