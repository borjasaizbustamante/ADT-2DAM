package EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb;

import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.dao.AbstractDAO;
import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.dao.EmpleadoDAO;
import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.dao.EmpresaDAO;
import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.exception.DaoFactoryException;

/**
 * This class is a Simple Factory meant for centralizing the creation of DAOs.
 * 
 * DO NOT make it Singleton, it is unnecessary in Springboot
 * 
 */
public class DaoFactory {

	public static final String DAO_EMPRESA = "daoEmpresa";
	public static final String DAO_EMPLEADO = "daoEmpleado";

	/**
	 * Generates and returns a new DAO of the chosen type
	 * 
	 * @param type
	 * @return The selected DAO
	 * @throws DaoFactoryException if a wrong type is chosen
	 */
	public AbstractDAO<?> getDao(String type) throws DaoFactoryException {
		AbstractDAO<?> ret = null;

		switch (type) {
		case DAO_EMPRESA:
			ret = new EmpresaDAO();
			break;
		case DAO_EMPLEADO:
			ret = new EmpleadoDAO();
			break;
		default:
			throw new DaoFactoryException();
		}

		return ret;
	}
}
