package EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.entity.Empresa;
import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.util.HibernateUtil;

/**
 * Dao for the Empresa
 */
public class EmpresaDAO extends AbstractDAO <Empresa> {

	@Override
	public List<Empresa> getAll() {
		List<Empresa> ret = null;
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction transaction = session.beginTransaction();

			// HQL -> Retorna todas las empresas
			ret = session.createQuery("FROM Empresa", Empresa.class).list();

			transaction.commit();

			session.close();
		} catch (Exception e) {
			System.out.println("Error en busqueda: " + e.getMessage());
		}

		return ret;
	}

	@Override
	public Empresa get(int id) {
		Empresa ret = null;
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction transaction = session.beginTransaction();

			ret = session.get(Empresa.class, id);

			transaction.commit();

			session.close();
		} catch (Exception e) {
			System.out.println("Error en busqueda: " + e.getMessage());
		}

		return ret;
	}

	@Override
	public void insert(Empresa empresa) {

		System.out.println("Insertando: " + empresa.toString());
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction transaction = session.beginTransaction();

			// Hibernate 6 no usa el metodo save ()
			session.persist(empresa);

			transaction.commit();

			session.close();

			System.out.println("Insertada");
		} catch (Exception e) {
			System.out.println("Error en Insercion: " + e.getMessage());
		}
	}

	@Override
	public void updateDetached(Empresa empresa) {
		System.out.println("Actualizando");
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction transaction = session.beginTransaction();

			// Si empresa viene Detached, usamos merge
			// Merge devuelve una instancia Persistent asociada a la sesion
			// Si empresa estaba Detached, Hibernate crea una copia y la sincroniza con BD
			session.merge(empresa);

			transaction.commit();

			session.close();

			System.out.println("Actualizada");
		} catch (Exception e) {
			System.out.println("Error en Actualizacion: " + e.getMessage());
		}
	}

	@Override
	public void updatePersistent(int id, String name) {
		System.out.println("Actualizando");
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction transaction = session.beginTransaction();

			// Hacemos primero Persistant la Empresa, lo que la sincroniza con la BBDD
			Empresa empresa = session.get(Empresa.class, id);
			empresa.setNombre("Elorrieta Academy");

			// El commit hace el update() automaticamente
			transaction.commit();

			session.close();

			System.out.println("Actualizada");
		} catch (Exception e) {
			System.out.println("Error en Actualizacion: " + e.getMessage());
		}
	}

	@Override
	public void deleteDetached(Empresa empresa) {
		System.out.println("Eliminando");
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction transaction = session.beginTransaction();

			// Si empresa viene Detached, usamos merge
			// Merge devuelve una instancia Persistent asociada a la sesion
			// Si empresa estaba Detached, Hibernate crea una copia y la sincroniza con BD
			Empresa managed = session.merge(empresa);
		    session.remove(managed);

			transaction.commit();

			session.close();

			System.out.println("Eliminada");
		} catch (Exception e) {
			System.out.println("Error en Eliminacion: " + e.getMessage());
		}
	}

	@Override
	public void deletePersistent(int id) {
		System.out.println("Eliminando");
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction transaction = session.beginTransaction();

            Empresa empresa = session.get(Empresa.class, id);
            if (empresa != null) {
                session.remove(empresa);
            }

			transaction.commit();

			session.close();

			System.out.println("Eliminada");
		} catch (Exception e) {
			System.out.println("Error en Eliminacion: " + e.getMessage());
		}
	}

}
