package EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.dao;

import java.util.List;

/**
 * Abstract Class for the factory
 */
public abstract class AbstractDAO <I>{

	public abstract List <I> getAll ();
	
	public abstract I get (int id);
	
	public abstract void insert (I i);
	
	public abstract void updateDetached (I i);
	
	public abstract void updatePersistent(int id, String name);
	
	public abstract void deleteDetached (I i);
	
	public abstract void deletePersistent(int id);
}
