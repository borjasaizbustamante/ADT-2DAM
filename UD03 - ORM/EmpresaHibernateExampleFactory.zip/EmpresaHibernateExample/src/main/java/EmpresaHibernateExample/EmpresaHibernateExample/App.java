package EmpresaHibernateExample.EmpresaHibernateExample;

import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.Menu;

public class App {

	public static void main(String[] args) {
		try {
			new Menu().init();
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
	}
}
