package EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.exception;

public class DaoFactoryException extends Exception{

	private static final long serialVersionUID = -7242240248101855157L;

}
