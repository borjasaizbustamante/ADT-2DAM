package EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.dao;

import java.util.List;

import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.entity.Empleado;

/**
 * Dao for the Empleado
 */
public class EmpleadoDAO extends AbstractDAO <Empleado>{

	@Override
	public List<Empleado> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Empleado get(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Empleado i) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDetached(Empleado i) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updatePersistent(int id, String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteDetached(Empleado i) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePersistent(int id) {
		// TODO Auto-generated method stub
		
	}

}
