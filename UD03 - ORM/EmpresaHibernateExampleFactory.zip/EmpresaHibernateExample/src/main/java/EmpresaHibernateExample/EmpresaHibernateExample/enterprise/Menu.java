package EmpresaHibernateExample.EmpresaHibernateExample.enterprise;

import java.util.List;
import java.util.Scanner;

import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.DaoFactory;
import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.dao.EmpresaDAO;
import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.entity.Empresa;
import EmpresaHibernateExample.EmpresaHibernateExample.enterprise.ddbb.exception.DaoFactoryException;

/**
 * The menu
 */
public class Menu {

	private Scanner scanner = null;

	public static final int NUMERO_OPCIONES_MENU = 5;

	public Menu() {
		scanner = new Scanner(System.in);
	}

	public void init() {
		int opcion = 0;
		do {
			opcion = optionMenuManager();
			if (opcion != 0) {
				try {
					doOptionMenu(opcion);
				} catch (Exception e) {
					System.out.println("Error: " + e.getMessage());
				}
			} else {
				System.out.print("¡Adiós!");
			}
		} while (opcion != 0);
		scanner.close();
	}

	private int optionMenuManager() {
		int ret = 0;
		do {
			try {
				printMenu();
				System.out.print("Elija una opción: ");
				ret = scanner.nextInt();
				scanner.nextLine();
			} catch (Exception e) {
				scanner.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > NUMERO_OPCIONES_MENU));
		return ret;
	}

	private void printMenu() {
		System.out.println(" ");
		System.out.println("---- MENÚ PRINCIPAL ----");
		System.out.println("0 - Salir");
		System.out.println("1 - Todas las Empresas ");
		System.out.println("2 - Buscar Empresa ");
		System.out.println("3 - Añadir Empresa");
		System.out.println("4 - Modificar Empresa ");
		System.out.println("5 - Borrar Empresa ");
		System.out.println("------------------------");
		System.out.println(" ");
	}

	private void doOptionMenu(int opcion) throws Exception {
		System.out.println();
		switch (opcion) {
		case 0 -> System.out.println("Adios!!");
		case 1 -> getAll();
		case 2 -> getById();
		case 3 -> insert();
		case 4 -> update();
		case 5 -> delete();
		default -> System.out.println("Invalid option");
		}
	}

	private void getAll() throws DaoFactoryException {
		// We get the factory
		DaoFactory daoFactory = new DaoFactory ();

		// We get the AbstractDAO
		EmpresaDAO empresaDAO = (EmpresaDAO) daoFactory.getDao(DaoFactory.DAO_EMPRESA);

		List<Empresa> empresas = empresaDAO.getAll();

		// We do something with the data...
		if (empresas == null) {
			System.out.println("No hay empresas");
		} else {
			for (Empresa empresa : empresas) {
				System.out.println("Empresa: " + empresa.toString());
			}
		}
	}

	private void getById() throws DaoFactoryException {
		// We get the factory
		DaoFactory daoFactory = new DaoFactory ();

		// We get the AbstractDAO
		EmpresaDAO empresaDAO = (EmpresaDAO) daoFactory.getDao(DaoFactory.DAO_EMPRESA);

		Empresa empresa = empresaDAO.get(1);

		if (empresa == null) {
			System.out.println("No hay empresa con esa id");
		} else {
			System.out.println("Empresa: " + empresa.toString());
		}
	}

	private void insert() throws DaoFactoryException {
		// We get the factory
		DaoFactory daoFactory = new DaoFactory ();

		// We get the AbstractDAO
		EmpresaDAO empresaDAO = (EmpresaDAO) daoFactory.getDao(DaoFactory.DAO_EMPRESA);
		empresaDAO.insert(new Empresa("Elorrieta Inc.", "Bilbao"));
	}

	private void update() throws DaoFactoryException {
		// We get the factory
		DaoFactory daoFactory = new DaoFactory ();

		// We get the AbstractDAO
		EmpresaDAO empresaDAO = (EmpresaDAO) daoFactory.getDao(DaoFactory.DAO_EMPRESA);
		Empresa empresaToUpdate = empresaDAO.get(2);

		if (empresaToUpdate == null) {
			System.out.println("No hay empresa con esa id");
		} else {
			empresaToUpdate.setNombre("NewEnterprise");
			empresaDAO.updateDetached(empresaToUpdate);
		}
	}

	private void delete() throws DaoFactoryException {
		// We get the factory
		DaoFactory daoFactory = new DaoFactory ();

		// We get the AbstractDAO
		EmpresaDAO empresaDAO = (EmpresaDAO) daoFactory.getDao(DaoFactory.DAO_EMPRESA);
		empresaDAO.deletePersistent(1);
	}
}
