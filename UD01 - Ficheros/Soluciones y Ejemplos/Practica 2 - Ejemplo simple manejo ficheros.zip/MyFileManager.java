package adt.ejercicios.resueltos.practicaDos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MyFileManager extends FileManager {

	public List<Student> readFile() {
		List<Student> ret = null;
		try {
			ret = readBinaryFile();
		} catch (Exception e) {
			System.out.println("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

	public void addStudent(Student student) {
		// Due the fact there is a HUGE problem with appending a file using
		// ObjectOutputStream, we do NOT use append. We simply read ALL the file, make
		// changes, and then overwrite it
		List<Student> students = readFile();
		try {
			if (null == students) {
				students = new ArrayList<Student>();
			}
			students.add(student);
			System.out.println("Estudiante añadido");
			writeBinaryFile(students);
		} catch (Exception e) {
			System.out.println("Error - " + e.getLocalizedMessage());
		}
	}

	public Student findStudent(String name) {
		// Due the fact there is a HUGE problem with appending a file using
		// ObjectOutputStream, we do NOT use append. We simply read ALL the file, make
		// changes, and then overwrite it
		Student ret = null;
		List<Student> students = readFile();
		try {
			if (null != students) {
				for (Student student : students) {
					if (student.getName().equals(name)) {
						ret = student;
						System.out.println("Estudiante encontrado");
						break;
					}
				}
				writeBinaryFile(students);
			} else {
				System.out.println("No hay estudiantes en el fichero");
			}
		} catch (Exception e) {
			System.out.println("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

	public void deleteStudent(String name) {
		// Due the fact there is a HUGE problem with appending a file using
		// ObjectOutputStream, we do NOT use append. We simply read ALL the file, make
		// changes, and then overwrite it
		List<Student> students = readFile();
		try {
			if (null != students) {
				for (Student student : students) {
					if (student.getName().equals(name)) {
						students.remove(student);
						System.out.println("Estudiante eliminado");
						break;
					}
				}
				writeBinaryFile(students);
			} else {
				System.out.println("No hay estudiantes en el fichero");
			}
		} catch (Exception e) {
			System.out.println("Error - " + e.getLocalizedMessage());
		}
	}

	public void sortFile() {
		try {
			List<Student> students = readFile();
			Collections.sort(students, Comparator.comparing(Student::getId));
			writeBinaryFile(students);
			System.out.println("Fichero ordenado de menor a mayor");
		} catch (Exception e) {
			System.out.println("Error - " + e.getLocalizedMessage());
		}
	}
}
