package adt.ejercicios.resueltos.practicaDos;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 * Your everyday regular Student
 */
public class Student implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer id = null;
	private String name = null;
	private String surName = null;
	private Date date = null;
	private Integer calification = null;

	public Student(Integer id, String name, String surName, Date date, Integer calification) {
		super();
		this.id = id;
		this.name = name;
		this.surName = surName;
		this.date = date;
		this.calification = calification;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Integer getCalification() {
		return calification;
	}

	public void setCalification(Integer calification) {
		this.calification = calification;
	}

	@Override
	public int hashCode() {
		return Objects.hash(calification, date, id, name, surName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(calification, other.calification) && Objects.equals(date, other.date)
				&& Objects.equals(id, other.id) && Objects.equals(name, other.name)
				&& Objects.equals(surName, other.surName);
	}

	@Override
	public String toString() {
		return "AlumnoPOJO [id=" + id + ", name=" + name + ", surName=" + surName + ", date=" + date + ", calification="
				+ calification + "]";
	}

}
