package adt.ejercicios.resueltos.practicaDos;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Menu {

	private Scanner teclado = null;
	public static final int NUMERO_OPCIONES_MENU = 5;

	private MyFileManager logicManager = null;

	public Menu() {
		teclado = new Scanner(System.in);
		logicManager = new MyFileManager();
	}

	public void iniciar() {
		int opcion = 0;
		do {
			opcion = opcionMenuInicial();
			if (opcion != 0) {
				try {
					ejecutarOpcionMenuInicial(opcion);
				} catch (Exception e) {
					System.out.println("Error: " + e.getMessage());
				}
			} else {
				System.out.print("¡Adiós!");
			}
		} while (opcion != 0);
		teclado.close();
	}

	private int opcionMenuInicial() {
		int ret = 0;
		do {
			try {
				escribirMenuInicial();
				System.out.print("Elija una opción: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > NUMERO_OPCIONES_MENU));
		return ret;
	}

	private void escribirMenuInicial() {
		System.out.println("\n---- MENÚ PRINCIPAL ----");
		System.out.println("0 - Salir");
		System.out.println("1 - Mostrar fichero");
		System.out.println("2 - Añadir Alumno");
		System.out.println("3 - Buscar Alumno");
		System.out.println("4 - Borrar Alumno");
		System.out.println("5 - Ordenar Alumnos");
		System.out.println("------------------------");
		System.out.println(" ");
	}

	private void ejecutarOpcionMenuInicial(int opcion) throws Exception {
		System.out.println();
		switch (opcion) {
		case 0:
			break;
		case 1:
			showStudents(logicManager.readFile());
			break;
		case 2:
			logicManager.addStudent(getStudent());
			break;
		case 3:
			showStudent(logicManager.findStudent(getStudentName()));
			break;
		case 4:
			logicManager.deleteStudent(getStudentName());
			break;
		case 5:
			logicManager.sortFile();
			showStudents(logicManager.readFile());
			break;
		default:
			System.out.println("Invalid option");
		}
	}

	private Student getStudent() {
		System.out.print("Dame la id: ");
		String id = teclado.nextLine();
		System.out.print("Dame el nombre: ");
		String name = teclado.nextLine();
		System.out.print("Dame el apellido: ");
		String surname = teclado.nextLine();
		System.out.println("La fecha es: " + new Date());
		Date date = new Date();
		System.out.print("Dame la nota: ");
		String nota = teclado.nextLine();
		return new Student(Integer.parseInt(id), name, surname, date, Integer.parseInt(nota));
	}

	private String getStudentName() {
		System.out.print("Dame el nombre: ");
		return teclado.nextLine();
	}

	private void showStudents(List<Student> students) {
		if (students == null) {
			System.out.print("No hay estudiantes...");
		} else {
			for (Student student : students)
				showStudent(student);
		}
	}

	private void showStudent(Student student) {
		if (student != null) {
			System.out.println(student.toString());
		} else {
			System.out.println("No hay estudiante");
		}
	}

	public static void main(String[] args) {
		new Menu().iniciar();
	}
}