package ficherosXML.manager;

import java.io.File;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ficherosXML.entity.Videogame;
import ficherosXML.entity.Videogames;

/**
 * The XML file manager. Singleton pattern.
 */
public class Manager implements ManagerInterface {

	private static final String FILE_PATH = "videogameManager.xml";

	private volatile static Manager instance = null;

	private Manager() {
	}

	public static Manager getInstance() {
		if (null == instance) {
			synchronized (Manager.class) {
				instance = null == instance ? new Manager() : instance;
			}
		}
		return instance;
	}

	// -- Interface methods --//

	@Override
	public Videogames getAll() {
		return readXML();
	}

	@Override
	public Videogame findVideogame(String name) {
		Videogame ret = null;
		Videogames videogames = readXML();

		videogames = null == videogames ? new Videogames() : videogames;

		for (Videogame videogame : videogames.getVideogames()) {
			ret = videogame.getName().equalsIgnoreCase(name) ? videogame : null;
			if (null != ret)
				break;
		}
		return ret;
	}

	@Override
	public void addNewVideogame(Videogame videogame) {
		Videogames videogames = readXML();

		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;
		try {
			factory = DocumentBuilderFactory.newInstance();
			builder = factory.newDocumentBuilder();
			Document document = builder.newDocument();

			videogames = null == videogames ? new Videogames() : videogames;

			videogames.getVideogames().add(videogame);
			Element videogamesElement = videoGamesToElement(document, videogames.getVideogames());
			document.appendChild(videogamesElement);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			DOMSource source = new DOMSource(document);
			StreamResult result = new StreamResult(new File(FILE_PATH));
			transformer.transform(source, result);

		} catch (Exception e) {
			System.out.println("ERROR - " + e.getMessage());
		}
	}

	@Override
	public boolean removeVideogame(String name) {
		boolean ret = false;
		Videogame videogame = findVideogame (name);
		if (null != videogame) {
			Videogames videogames = getAll();
			videogames.getVideogames().remove(videogame);
			
			// Añadimos todo a lo bruto
			new File(FILE_PATH); // Nos cargamos el fichero 
			generateEmptyXMLFile (false); // Lo dejamos en blanco
			videogames.getVideogames().forEach(vid -> addNewVideogame(vid));
			ret = true;
		} 
		return ret;
	}

	@Override
	public boolean renameVideogame(String name1, String name2) {
		boolean ret = false;
		Videogame videogame = findVideogame (name1);
		if (null != videogame) {
			Videogames videogames = getAll();
			for (Videogame vid : videogames.getVideogames()) {
				if (vid.equals(videogame)) {
					vid.setName(name2);
					
					// Añadimos todo a lo bruto
					new File(FILE_PATH); // Nos cargamos el fichero 
					generateEmptyXMLFile (false); // Lo dejamos en blanco
					videogames.getVideogames().forEach(vide -> addNewVideogame(vide));
					ret = true;
					break;
				}
			}
		} 
		return ret;
	}

	// -- File managing methods --//

	/**
	 * Reads the full XML file, given the tag <Videogames> exists, empty or not
	 * 
	 * @return Videogames
	 */
	private Videogames readXML() {
		Videogames ret = null;

		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;
		try {
			factory = DocumentBuilderFactory.newInstance();
			builder = factory.newDocumentBuilder();

			Document document = builder.parse(new File(FILE_PATH));
			document.getDocumentElement().normalize();

			// Elemento raiz <videogames>
			Element elementVideogame = document.getDocumentElement();

			// Sacamos la lista de <videogame>
			NodeList videogamesNodeList = elementVideogame.getElementsByTagName("videogame");

			// Recorremos la lista
			for (int i = 0; i < videogamesNodeList.getLength(); i++) {
				Node videogameNode = videogamesNodeList.item(i);
				if (videogameNode.getNodeType() == Node.ELEMENT_NODE) {
					// Un <videogame> suelto
					Element element = (Element) videogameNode;
					Videogame videogame = elementToVideoGame(element);
					ret = null == ret ? new Videogames() : ret;
					ret.getVideogames().add(videogame);
				}
			}
		} catch (Exception e) {
			System.out.println("ERROR - " + e.getMessage());
		}
		return ret;
	}

	/**
	 * Generates a Videogame POJO from an Element
	 * 
	 * @param element
	 * @return the Videogame POJO
	 */
	private Videogame elementToVideoGame(Element element) {
		Videogame ret = new Videogame();

		NodeList childNodes = element.getChildNodes();
		for (int i = 0; i < childNodes.getLength(); i++) {
			Node childNode = childNodes.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				Element childElement = (Element) childNode;
				switch (childElement.getNodeName()) {
				case "name":
					ret.setName(childElement.getTextContent().trim());
					break;
				case "distribuidor":
					ret.setDistribuidor(childElement.getTextContent().trim());
					break;
				case "fecha":
					ret.setFecha(childElement.getTextContent().trim());
					break;
				case "tipo":
					ret.setTipo(childElement.getTextContent().trim());
					break;
				case "jugadores":
					ret.setJugadores(childElement.getTextContent().trim());
					break;
				default:
					System.out.println(childElement.getNodeName());
				}
			}
		}
		return ret;
	}

	/**
	 * Returns true if the XML file exists
	 */
	public boolean checkIfXMLFileExist() {
		return new File(FILE_PATH).exists();
	}

	/**
	 * Generates the an empty XML File, only if it does not exists
	 * 
	 * @param exists
	 */
	public void generateEmptyXMLFile(boolean exists) {

		if (!exists) {
			DocumentBuilderFactory factory = null;
			DocumentBuilder builder = null;

			try {
				factory = DocumentBuilderFactory.newInstance();
				builder = factory.newDocumentBuilder();

				Document document = builder.newDocument();
				Element root = document.createElement("videogames");
				document.appendChild(root);

				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();

				DOMSource source = new DOMSource(document);
				StreamResult result = new StreamResult(new File(FILE_PATH));
				transformer.transform(source, result);
			} catch (Exception e) {
				System.out.println("ERROR - " + e.getMessage());
			}
		}
	}

	/**
	 * Generates a <Videogames> Element to add into the XML
	 * 
	 * @param document
	 * @param videogames
	 * @return the Element Videogames
	 */
	private Element videoGamesToElement(Document document, List<Videogame> videogames) {
		Element videogamesElement = document.createElement("videogames");
		for (Videogame videogame : videogames) {
			videogamesElement.appendChild(videoGameToElement(document, videogame));
		}
		return videogamesElement;
	}

	/**
	 * Generates a <Videogame> Element to add into the XML
	 * 
	 * @param document
	 * @param videogame
	 * @return the Element Videogame
	 */
	private Element videoGameToElement(Document document, Videogame videogame) {
		Element videogameElement = document.createElement("videogame");

		Element name = document.createElement("name");
		name.appendChild(document.createTextNode(videogame.getName()));
		videogameElement.appendChild(name);

		Element distribuidor = document.createElement("distribuidor");
		distribuidor.appendChild(document.createTextNode(videogame.getDistribuidor()));
		videogameElement.appendChild(distribuidor);

		Element fecha = document.createElement("fecha");
		fecha.appendChild(document.createTextNode(videogame.getFecha()));
		videogameElement.appendChild(fecha);

		Element tipo = document.createElement("tipo");
		tipo.appendChild(document.createTextNode(videogame.getTipo()));
		videogameElement.appendChild(tipo);

		Element jugadores = document.createElement("jugadores");
		jugadores.appendChild(document.createTextNode(videogame.getJugadores()));
		videogameElement.appendChild(jugadores);

		return videogameElement;
	}
}
