package ficherosXML.manager;

import ficherosXML.entity.Videogame;
import ficherosXML.entity.Videogames;

/**
 * The Interface
 */
public interface ManagerInterface {

	/**
	 * Returns all Videogames with all the available Videogame, or a Videogame with
	 * an empty list
	 * 
	 * @return Videogames
	 */
	public Videogames getAll();

	/**
	 * Returns the Videogame by name, or null if it does not exist in file
	 * 
	 * @param name
	 * @return The Videogame or null
	 */
	public Videogame findVideogame(String name);

	/**
	 * Adds a new videogame
	 * 
	 * @param videogame
	 */
	public void addNewVideogame(Videogame videogame);

	/**
	 * Removes the videogame, returns if done so
	 * 
	 * @param name
	 * @return True or False
	 */
	public boolean removeVideogame(String name);

	/**
	 * Renames the videogame named name1 and replaces it with name2
	 * 
	 * @param name1
	 * @param name2
	 * @return
	 */
	public boolean renameVideogame(String name1, String name2);
}
