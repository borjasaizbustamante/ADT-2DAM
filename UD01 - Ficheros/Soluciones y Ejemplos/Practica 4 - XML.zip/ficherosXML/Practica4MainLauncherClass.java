package ficherosXML;

import java.util.Scanner;

import ficherosXML.entity.Videogame;
import ficherosXML.entity.Videogames;
import ficherosXML.manager.Manager;

public class Practica4MainLauncherClass {

	private Scanner scanner = null;

	public static final int NUMERO_OPCIONES_MENU = 5;

	public Practica4MainLauncherClass() {
		scanner = new Scanner(System.in);
		Manager.getInstance().generateEmptyXMLFile(Manager.getInstance().checkIfXMLFileExist());
	}

	public void init() {
		int opcion = 0;
		do {
			opcion = optionMenuManager();
			if (opcion != 0) {
				try {
					doOptionMenu(opcion);
				} catch (Exception e) {
					System.out.println("Error: " + e.getMessage());
				}
			} else {
				System.out.print("¡Adiós!");
			}
		} while (opcion != 0);
		scanner.close();
	}

	private int optionMenuManager() {
		int ret = 0;
		do {
			try {
				printMenu();
				System.out.print("Elija una opción: ");
				ret = scanner.nextInt();
				scanner.nextLine();
			} catch (Exception e) {
				scanner.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > NUMERO_OPCIONES_MENU));
		return ret;
	}

	private void printMenu() {
		System.out.println("\n---- MENÚ PRINCIPAL ----");
		System.out.println("0 - Salir");
		System.out.println("1 - Mostrar todos");
		System.out.println("2 - Buscar");
		System.out.println("3 - Nuevo");
		System.out.println("4 - Baja");
		System.out.println("5 - Modificar nombre");
		System.out.println("------------------------");
	}

	private void doOptionMenu(int opcion) throws Exception {
		System.out.println();
		switch (opcion) {
		case 0:
			System.out.println("-- BYE!! ");
			break;
		case 1:
			showAll(Manager.getInstance().getAll());
			break;
		case 2:
			show(Manager.getInstance().findVideogame(getVideogameThingy("Nombre del videojuego: ")));
			break;
		case 3:
			Manager.getInstance().addNewVideogame(getNewVideogame());
			System.out.println("-- Añadido ");
			break;
		case 4:
			if (Manager.getInstance().removeVideogame(getVideogameThingy("Nombre del videojuego: "))) {
				System.out.println("-- Cambiado ");
			} else {
				System.out.println("-- No existe ");
			}
			break;
		case 5:
			if (Manager.getInstance().renameVideogame(getVideogameThingy("Nombre del videojuego: "),
					getVideogameThingy("Nuevo nombre: "))) {
				System.out.println("-- Modificado ");
			} else {
				System.out.println("-- No existe ");
			}
			break;
		default:
			System.out.println("Opción no válida");
		}
	}

	private void showAll(Videogames videogames) {
		System.out.println("-- Videogames ");
		if (null != videogames && null != videogames.getVideogames()) {
			videogames.getVideogames().forEach(videogame -> show(videogame));
		} else {
			System.out.println("No records...");
		}
	}

	private void show(Videogame videogame) {
		if (null != videogame)
			System.out.println(videogame.toString());
		else
			System.out.println("No records...");
	}

	private String getVideogameThingy(String text) {
		System.out.print(text);
		return scanner.nextLine().trim();
	}

	private Videogame getNewVideogame() {
		Videogame ret = new Videogame();
		ret.setName(getVideogameThingy("Nombre del videojuego: "));
		ret.setDistribuidor(getVideogameThingy("Distribuidor del videojuego: "));
		ret.setFecha(getVideogameThingy("Fecha del videojuego: "));
		ret.setTipo(getVideogameThingy("Tipo de videojuego: "));
		ret.setJugadores(getVideogameThingy("Jugadores del videojuego: "));
		return ret;
	}

	public static void main(String[] args) {
		new Practica4MainLauncherClass().init();
	}
}
