package pmdm_server_final_2.zFirestoreExample;

import pmdm_server_final_2.zFirestoreExample.model.exceptions.FireBaseException;
import pmdm_server_final_2.zFirestoreExample.view.Menu;

public class App {
	public static void main(String[] args) {
		try {
			new Menu().init();
		} catch (FireBaseException e) {
			System.out.println("Error: No se puede inicialziar Firebase. Comprueba el fichero de credenciales");
			System.out.println("Error: " + e.getMessage());
		}
	}
}
