package processOne;

import java.io.File;

public class PrimaryProcess {

	public static void main(String[] args) {
		System.out.println("Primary process running...");
		System.out.println("Launching secondary process...");
		
		ProcessBuilder processBuilder = null;
		Process process = null;
		try {
			// We prepare de builders...
			processBuilder = new ProcessBuilder("java", "es.ProcesoSecundario");
			processBuilder.directory(new File("bin"));
			process = processBuilder.start();

			// The primary process waits until secondary process ends
			int valorRetorno = process.waitFor();
			if (valorRetorno == 0) {
				System.out.println("Secondary process finsished!!");
			} else {
				System.out.println("Secondary process finsished with errors: " + valorRetorno);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
