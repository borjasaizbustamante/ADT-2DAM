package ficherosXML.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * A collection of videogames
 */
public class Videogames implements Serializable {

	private static final long serialVersionUID = -1529549162957126012L;

	private List<Videogame> videogames = null;

	public Videogames() {
		videogames = new ArrayList<Videogame>();
	}

	public List<Videogame> getVideogames() {
		return videogames;
	}

	public void setVideogames(List<Videogame> videogames) {
		this.videogames = videogames;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(videogames);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Videogames other = (Videogames) obj;
		return Objects.equals(videogames, other.videogames);
	}

	@Override
	public String toString() {
		return "Videogames [videogames=" + videogames + "]";
	}

}
