package ficherosXML.entity;

import java.io.Serializable;
import java.util.Objects;

/**
 * A single videogame
 */
public class Videogame implements Serializable {

	private static final long serialVersionUID = -8888853388370292038L;

	private String name = null;
	private String distribuidor = null;
	private String fecha = null;
	private String tipo = null;
	private String jugadores = null;

	public Videogame() {
	}

	public Videogame(String name, String distribuidor, String fecha, String tipo, String jugadores) {
		super();
		this.name = name;
		this.distribuidor = distribuidor;
		this.fecha = fecha;
		this.tipo = tipo;
		this.jugadores = jugadores;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDistribuidor() {
		return distribuidor;
	}

	public void setDistribuidor(String distribuidor) {
		this.distribuidor = distribuidor;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getJugadores() {
		return jugadores;
	}

	public void setJugadores(String jugadores) {
		this.jugadores = jugadores;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(distribuidor, fecha, jugadores, name, tipo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Videogame other = (Videogame) obj;
		return Objects.equals(distribuidor, other.distribuidor) && Objects.equals(fecha, other.fecha)
				&& Objects.equals(jugadores, other.jugadores) && Objects.equals(name, other.name)
				&& Objects.equals(tipo, other.tipo);
	}

	@Override
	public String toString() {
		return "VideojuegoPOJO [name=" + name + ", distribuidor=" + distribuidor + ", fecha=" + fecha + ", tipo=" + tipo
				+ ", jugadores=" + jugadores + "]";
	}

}
