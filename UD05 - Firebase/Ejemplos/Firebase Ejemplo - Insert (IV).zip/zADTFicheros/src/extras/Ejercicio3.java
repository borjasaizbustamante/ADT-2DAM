package extras;

import java.io.InputStream;

/**
 * Ejecuta el la consola de windows (CMD) como un proceso separado. Solicita la
 * dirección MAC. Redirigimos la salida estandar del proceso CMD para que lo que
 * escriba por pantalla llegue al proceso padre. Escribe el resultado por
 * pantalla.
 */
public class Ejercicio3 {

	public static void main(String[] args) {
		ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", "getmac");

		InputStream inputStream = null;
		try {
			Process process = processBuilder.start();
			inputStream = process.getInputStream();
			int c;
			while ((c = inputStream.read()) != -1) {
				System.out.print((char) c);
			}
			inputStream.close();
		} catch (Exception e) {
			System.out.println("Error: " + e);
		} finally {
			try {
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}
		}
	}
}
