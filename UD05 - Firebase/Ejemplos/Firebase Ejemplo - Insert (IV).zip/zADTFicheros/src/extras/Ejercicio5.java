package extras;

import java.io.InputStream;

/**
 * Ejecuta el la consola de windows (CMD) como un proceso separado. Busca el
 * proceso Notepad.exe en el listado de procesos. Si existe, lo matamos.
 * Redirigimos la salida estandar del proceso CMD para que lo que escriba por
 * pantalla llegue al proceso padre. Escribe el resultado por pantalla.
 */
public class Ejercicio5 {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// Comando para buscar el proceso Notepad.exe en el listado de procesos
		ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", "tasklist | findstr Notepad.exe");

		InputStream inputStream = null;
		try {
			Process process = processBuilder.start();
			inputStream = process.getInputStream();
			String salida = "";
			int c;
			while ((c = inputStream.read()) != -1) {
				salida += (char) c;
			}

			if (salida.contains("Notepad.exe")) {
				Runtime.getRuntime().exec("taskkill /F /IM Notepad.exe");
				System.out.println("> El Bloc de Notas se ha cerrado.");
			} else {
				System.out.println("> El Bloc de Notas no está abierto.");
			}

		} catch (Exception e) {
			System.out.println("Error: " + e);
		} finally {
			try {
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}
		}
	}

}
