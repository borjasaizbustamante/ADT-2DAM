package extras;

/**
 * Ejecuta el notepad como un proceso separado.
 */
public class Ejercicio1 {

	public static void main(String[] args) {
		ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", "notepad");
		
		try {
			processBuilder.start();
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
}
