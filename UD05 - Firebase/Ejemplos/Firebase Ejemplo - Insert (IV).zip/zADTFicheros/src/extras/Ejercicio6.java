package extras;

import java.io.File;

/**
 * Programa que ejecuta un “.bat” previamente preparado y recoge la salida en un
 * archivo y los errores en otro.
 */
public class Ejercicio6 {

	public static void main(String[] args) {

		// Carpeta de los archivos
		String carpeta = "src\\ejercicio1\\archivos\\";

		// Rutas de los archivos
		String bat = carpeta + "ej6.bat";
		String output = carpeta + "output_ej6.txt";
		String error = carpeta + "error_ej6.txt";

		try {
			ProcessBuilder processBuilder = new ProcessBuilder(bat);
			processBuilder.redirectOutput(new File(output));
			processBuilder.redirectError(new File(error));
			processBuilder.start();
		} catch (Exception e) {
			System.out.println("Error" + e);
		}
	}
}
