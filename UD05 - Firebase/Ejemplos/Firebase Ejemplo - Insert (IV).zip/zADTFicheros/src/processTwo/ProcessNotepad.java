package processTwo;

import java.util.Map;

public class ProcessNotepad {

	public static void main(String[] args) {
		System.out.println("Launching notepad...");

		try {
			ProcessBuilder processBuilder = new ProcessBuilder("Notepad.exe");
			
			// Info about the process
			Map <String, String> environment = processBuilder.environment();
			String number = environment.get ("NUMBER_OF_PROCESSORS");
			System.out.println("Numero de procesadores: " + number);
			
			// Start the notepad
			Process process = processBuilder.start();
			
			long pid = process.pid();
			System.out.println("Process PID: " + pid);
			
			// The primary process waits until secondary process ends
			int valorRetorno = process.waitFor();
			System.out.println("Secondary process finsished! - " + valorRetorno);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
