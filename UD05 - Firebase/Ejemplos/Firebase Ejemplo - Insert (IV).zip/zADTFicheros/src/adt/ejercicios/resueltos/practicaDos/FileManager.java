package adt.ejercicios.resueltos.practicaDos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class FileManager {

	private static final String FILE_NAME = "students.dat";
	
	protected void writeBinaryFile(List<Student> students) throws Exception {
		File file = null;
		FileOutputStream outputStream = null;
		ObjectOutputStream objectOutputStream = null;
		try {
			file = new File(FILE_NAME);
			outputStream = new FileOutputStream(file);
			objectOutputStream = new ObjectOutputStream(outputStream);
			for (Student student : students) {
				objectOutputStream.writeObject(student);
				objectOutputStream.flush();
			}
		} finally {
			// Close the ObjectOutputStream
			try {
				if (objectOutputStream != null)
					objectOutputStream.close();
			} catch (IOException e) {
				// Nothing to do here...
			}
			// Close the FileOutputStream
			try {
				if (outputStream != null)
					outputStream.close();
			} catch (IOException e) {
				// Nothing to do here...
			}
		}
	}

	protected List<Student> readBinaryFile() throws Exception {
		List<Student> ret = null;
		File file = null;
		FileInputStream inputStream = null;
		ObjectInputStream objectInputStream = null;
		try {
			file = new File(FILE_NAME);
			inputStream = new FileInputStream(file);
			objectInputStream = new ObjectInputStream(inputStream);
			ret = new ArrayList<Student> ();
			while (inputStream.getChannel().position() < inputStream.getChannel().size()) {
				ret.add((Student) objectInputStream.readObject());
			}
		} finally {
			// Close the ObjectInputStream
			try {
				if (objectInputStream != null)
					objectInputStream.close();
			} catch (IOException e) {
				// Nothing to do here...
			}
			// Close the FileInputStream
			try {
				if (inputStream != null)
					inputStream.close();
			} catch (IOException e) {
				// Nothing to do here...
			}
		}
		return ret;
	}
}
