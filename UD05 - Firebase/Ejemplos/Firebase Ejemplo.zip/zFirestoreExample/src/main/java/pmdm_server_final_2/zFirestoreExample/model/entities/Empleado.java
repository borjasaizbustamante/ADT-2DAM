package pmdm_server_final_2.zFirestoreExample.model.entities;

import java.io.Serializable;
import java.util.Objects;

public class Empleado implements Serializable {

	private static final long serialVersionUID = -6619513647860363379L;

	private String id = null;
	private String nombre = null;
	private String apellido = null;
	private String oficio = null;
	private String direccion = null;
	private String fecha = null;
	private String salario = null;
	private String comision = null;
	private Empresa empresa = null;

	public Empleado() {
	}
			
	public Empleado(String id, String nombre, String apellido, String oficio, String direccion, String fecha,
			String salario, Empresa empresa) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.oficio = oficio;
		this.direccion = direccion;
		this.fecha = fecha;
		this.salario = salario;
		this.empresa = empresa;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getOficio() {
		return oficio;
	}

	public void setOficio(String oficio) {
		this.oficio = oficio;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getSalario() {
		return salario;
	}

	public void setSalario(String salario) {
		this.salario = salario;
	}

	public String getComision() {
		return comision;
	}

	public void setComision(String comision) {
		this.comision = comision;
	}

	public Empresa getEmpresa() {
		return empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(apellido, comision, direccion, empresa, fecha, id, nombre, oficio, salario);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		return Objects.equals(apellido, other.apellido) && Objects.equals(comision, other.comision)
				&& Objects.equals(direccion, other.direccion) && Objects.equals(empresa, other.empresa)
				&& Objects.equals(fecha, other.fecha) && Objects.equals(id, other.id)
				&& Objects.equals(nombre, other.nombre) && Objects.equals(oficio, other.oficio)
				&& Objects.equals(salario, other.salario);
	}

	@Override
	public String toString() {
		return "Empleado [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", oficio=" + oficio
				+ ", direccion=" + direccion + ", fecha=" + fecha + ", salario=" + salario + ", comision=" + comision
				+ ", empresa=" + empresa + "]";
	}

}
