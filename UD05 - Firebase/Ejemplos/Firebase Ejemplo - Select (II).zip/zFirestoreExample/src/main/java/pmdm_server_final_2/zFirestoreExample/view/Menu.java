package pmdm_server_final_2.zFirestoreExample.view;

import java.util.List;
import java.util.Scanner;

import pmdm_server_final_2.zFirestoreExample.model.entities.Empresa;
import pmdm_server_final_2.zFirestoreExample.model.operations.OperacionesEmpresa;

public class Menu {

	private Scanner scanner = null;
	public static final int NUMERO_OPCIONES_MENU = 2;

	public Menu() {
		scanner = new Scanner(System.in);
	}

	public void init() {
		int opcion = 0;
		do {
			opcion = optionMenuManager();
			if (opcion != 0) {
				try {
					doOptionMenu(opcion);
				} catch (Exception e) {
					System.out.println("Error: " + e.getMessage());
				}
			} else {
				System.out.print("¡Adiós!");
			}
		} while (opcion != 0);
		scanner.close();
	}

	private int optionMenuManager() {
		int ret = 0;
		do {
			try {
				printMenu();
				System.out.print("Elija una opción: ");
				ret = scanner.nextInt();
				scanner.nextLine();
			} catch (Exception e) {
				scanner.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > NUMERO_OPCIONES_MENU));
		return ret;
	}

	private void printMenu() {
		System.out.println(" ");
		System.out.println("---- MENÚ PRINCIPAL ----");
		System.out.println("0 - Salir");
		System.out.println("1 - Todas las Empresas ");
		System.out.println("2 - Buscar Empresa ");
		System.out.println("------------------------");
		System.out.println(" ");
	}

	private void doOptionMenu(int opcion) throws Exception {
		System.out.println();
		switch (opcion) {
		case 0:
			System.out.println("Adios!!");
			break;
		case 1:
			printEmpresas(OperacionesEmpresa.getInstance().getEmpresas());
			break;
		case 2:
			printEmpresa(OperacionesEmpresa.getInstance().getEmpresa(getThingy("Nombre de empresa: ")));
			break;
		default:
			System.out.println("Invalid option");
		}
	}

	private String getThingy(String text) {
		System.out.print(text);
		return scanner.nextLine().trim();
	}

	private void printEmpresas(List <Empresa> empresas) {
		for (Empresa empresa : empresas) {
			printEmpresa(empresa);
		}
	}
	
	private void printEmpresa(Empresa empresa) {
		if (null != empresa)
			System.out.println(empresa.toString());
		else
			System.out.println("No hay documento");
	}
}
