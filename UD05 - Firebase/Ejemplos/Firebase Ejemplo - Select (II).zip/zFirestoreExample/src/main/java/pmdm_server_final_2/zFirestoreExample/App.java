package pmdm_server_final_2.zFirestoreExample;

import pmdm_server_final_2.zFirestoreExample.view.Menu;

public class App {
	public static void main(String[] args) {
		new Menu().init();
	}
}
