package pmdm_server_final_2.zFirestoreExample.model.operations;

import java.util.List;

import pmdm_server_final_2.zFirestoreExample.model.entities.Empleado;
import pmdm_server_final_2.zFirestoreExample.model.entities.Empresa;
import pmdm_server_final_2.zFirestoreExample.model.exceptions.FireBaseException;

public interface OperacionesInterface {

	/**
	 * Retorna todas las empresas, o null si no hay empresas
	 * 
	 * @param name
	 * @return listado de empresas o null
	 * @throws FireBaseException si algo sale mal
	 */
	public List<Empresa> getEmpresas() throws FireBaseException;

	/**
	 * Retorna la empresa dado un nombre, o null si no la encuentra
	 * 
	 * @param name
	 * @return la empresa o null
	 * @throws FireBaseException si algo sale mal
	 */
	public Empresa getEmpresa(String name) throws FireBaseException;

	/**
	 * Retorna la empresa dado una id, o null si no la encuentra
	 * 
	 * @param id
	 * @return la empresa o null
	 * @throws FireBaseException si algo sale mal
	 */
	public Empresa getEmpresaByID(String id) throws FireBaseException;
	
	/**
	 * Retorna el empleado dado un nombre, incluido la empresa a la que pertenece; o
	 * null si no la encuentra
	 * 
	 * @param name
	 * @return la empleado o null
	 * @throws FireBaseException si algo sale mal
	 */
	public Empleado getEmpleado(String name) throws FireBaseException;
}
