package pmdm_server_final_2.zFirestoreExample.model.operations;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;

import pmdm_server_final_2.zFirestoreExample.model.entities.Empresa;

public class OperacionesEmpresa {

	private volatile static OperacionesEmpresa instance = null;

	private OperacionesEmpresa() {
	}

	public static OperacionesEmpresa getInstance() {
		if (null == instance) {
			synchronized (OperacionesEmpresa.class) {
				instance = null == instance ? new OperacionesEmpresa() : instance;
			}
		}
		return instance;
	}

	/**
	 * Retorna todas las empresas, o null si no hay empresas
	 * 
	 * @param name
	 * @return listado de empresas o null
	 */
	public List<Empresa> getEmpresas() {
		List<Empresa> ret = null;

		try {
			// Comprobar si ya hay una instancia DEFAULT
			// Es decir, si ya hemos conectado con firebase antes
			if (FirebaseApp.getApps().isEmpty()) {
				InputStream serviceAccount = OperacionesEmpresa.class.getResourceAsStream("/EmpresaBD.json");
				FirebaseOptions options = FirebaseOptions.builder()
						.setCredentials(GoogleCredentials.fromStream(serviceAccount)).build();
				FirebaseApp.initializeApp(options);
			}

			Firestore dataBase = FirestoreClient.getFirestore();

			// Query...
			ApiFuture<QuerySnapshot> query = dataBase.collection("EmpresaBD").get();

			// Procesamos la query...
			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> empresas = querySnapshot.getDocuments();
			for (QueryDocumentSnapshot empresa : empresas) {
				ret = null == ret ? new ArrayList<Empresa>() : ret;
				ret.add(new Empresa(empresa.getId(), empresa.getString("nombre"), empresa.getString("localizacion")));
			}

		} catch (Exception e) {
			System.out.println("Error - " + e.getLocalizedMessage());
		}

		return ret;
	}

	/**
	 * Retorna la empresa dado un nombre, o null si no la encuentra
	 * 
	 * @param name
	 * @return la empresa o null
	 */
	public Empresa getEmpresa(String name) {
		Empresa ret = null;
		try {
			// Comprobar si ya hay una instancia DEFAULT
			// Es decir, si ya hemos conectado con firebase antes
			if (FirebaseApp.getApps().isEmpty()) {
				InputStream serviceAccount = OperacionesEmpresa.class.getResourceAsStream("/EmpresaBD.json");
				FirebaseOptions options = FirebaseOptions.builder()
						.setCredentials(GoogleCredentials.fromStream(serviceAccount)).build();
				FirebaseApp.initializeApp(options);
			}
			
			Firestore dataBase = FirestoreClient.getFirestore();

			// Query...
			ApiFuture<QuerySnapshot> query = dataBase.collection("EmpresaBD").whereEqualTo("nombre", name).get();

			// Procesamos la query...
			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> empresas = querySnapshot.getDocuments();
			for (QueryDocumentSnapshot empresa : empresas) {
				ret = new Empresa(empresa.getId(), empresa.getString("nombre"), empresa.getString("localizacion"));
			}

		} catch (Exception e) {
			System.out.println("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

}
