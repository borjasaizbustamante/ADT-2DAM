package pmdm_server_final_2.zFirestoreExample.model.operations;

import java.util.List;

import pmdm_server_final_2.zFirestoreExample.model.entities.Empleado;
import pmdm_server_final_2.zFirestoreExample.model.entities.Empresa;
import pmdm_server_final_2.zFirestoreExample.model.exceptions.FireBaseException;

public interface OperacionesInterface {

	/**
	 * Retorna todas las empresas, o null si no hay empresas
	 * 
	 * @param name
	 * @return listado de empresas o null
	 * @throws FireBaseException si algo sale mal
	 */
	public List<Empresa> getEmpresas() throws FireBaseException;

	/**
	 * Retorna la empresa dado un nombre, o null si no la encuentra
	 * 
	 * @param name
	 * @return la empresa o null
	 * @throws FireBaseException si algo sale mal
	 */
	public Empresa getEmpresa(String name) throws FireBaseException;

	/**
	 * Retorna la empresa dado una id, o null si no la encuentra
	 * 
	 * @param id
	 * @return la empresa o null
	 * @throws FireBaseException si algo sale mal
	 */
	public Empresa getEmpresaByID(String id) throws FireBaseException;

	/**
	 * Retorna el empleado dado un nombre, incluido la empresa a la que pertenece; o
	 * null si no la encuentra
	 * 
	 * @param name
	 * @return la empleado o null
	 * @throws FireBaseException si algo sale mal
	 */
	public Empleado getEmpleado(String name) throws FireBaseException;

	/**
	 * Añade una empresa a Firebase. NOTA: El id (de Firebase) se añade manualmente
	 * 
	 * @param empresa
	 * @throws FireBaseException
	 */
	public void addEmpresa(Empresa empresa) throws FireBaseException;

	/**
	 * Añade una empresa a Firebase. NOTA: El id (de Firebase) se autogenera
	 * 
	 * @param empresa
	 * @throws FireBaseException
	 */
	public void addEmpresaAutogen(Empresa empresa) throws FireBaseException;

	/**
	 * Añade un empleado a una empresa que ya existe. Retorna True si la empresa
	 * existe y lo inserta, False si no existe
	 * 
	 * @param empleado
	 * @param nameEmpresa
	 * @return true or false
	 * @throws FireBaseException
	 */
	public boolean addEmpleadoAEmpresa(Empleado empleado, String nameEmpresa) throws FireBaseException;

	/**
	 * Retorna true si cambia un empleado por otro empleado. No cambia las ID ni la
	 * referencia a la empresa. Falso en cualquier otro caso.
	 * 
	 * @param nombre
	 * @param empleadoNuevo
	 * @throws FireBaseException
	 */
	public boolean changeEmpleado(String nombre, Empleado empleadoNuevo) throws FireBaseException;

	/**
	 * Retorna true si elimina al empleado. Falso en cualquier otro caso.
	 * 
	 * @param nombre
	 * @throws FireBaseException
	 */
	public boolean deleteEmpleado(String nombre) throws FireBaseException;

	/**
	 * Retorna true si elimina al empleado de la Empresa. Falso en cualquier otro
	 * caso.
	 * 
	 * @param empleado
	 * @throws FireBaseException
	 */
	public boolean despedirEmpleado(String nombre) throws FireBaseException;
}
