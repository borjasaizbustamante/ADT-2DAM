package pmdm_server_final_2.zFirestoreExample.view;

import java.util.List;
import java.util.Scanner;

import pmdm_server_final_2.zFirestoreExample.model.entities.Empleado;
import pmdm_server_final_2.zFirestoreExample.model.entities.Empresa;
import pmdm_server_final_2.zFirestoreExample.model.exceptions.FireBaseException;
import pmdm_server_final_2.zFirestoreExample.model.operations.OperacionesFirebase;

public class Menu {

	private Scanner scanner = null;
	public static final int NUMERO_OPCIONES_MENU = 9;

	private OperacionesFirebase operacionesEmpresa = null;

	public Menu() throws FireBaseException {
		scanner = new Scanner(System.in);
		operacionesEmpresa = new OperacionesFirebase();
	}

	public void init() {
		int opcion = 0;
		do {
			opcion = optionMenuManager();
			if (opcion != 0) {
				try {
					doOptionMenu(opcion);
				} catch (Exception e) {
					System.out.println("Error: " + e.getMessage());
				}
			} else {
				System.out.print("¡Adiós!");
			}
		} while (opcion != 0);
		scanner.close();
	}

	private int optionMenuManager() {
		int ret = 0;
		do {
			try {
				printMenu();
				System.out.print("Elija una opción: ");
				ret = scanner.nextInt();
				scanner.nextLine();
			} catch (Exception e) {
				scanner.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > NUMERO_OPCIONES_MENU));
		return ret;
	}

	private void printMenu() {
		System.out.println(" ");
		System.out.println("---- MENÚ PRINCIPAL ----");
		System.out.println("0 - Salir");
		System.out.println("1 - Todas las Empresas ");
		System.out.println("2 - Buscar Empresa ");
		System.out.println("3 - Buscar Empleado y su Empresa ");
		System.out.println("4 - Añadir Empresa (ID manual)");
		System.out.println("5 - Añadir Empresa (ID autogen)");
		System.out.println("6 - Añadir Empleado a Empresa ");
		System.out.println("7 - Modificar Empleado ");
		System.out.println("8 - Borrar Empleado ");
		System.out.println("9 - Despedir Empleado ");
		System.out.println("------------------------");
		System.out.println(" ");
	}

	private void doOptionMenu(int opcion) throws Exception {
		System.out.println();
		switch (opcion) {
		case 0:
			System.out.println("Adios!!");
			break;
		case 1:
			printEmpresas(operacionesEmpresa.getEmpresas());
			break;
		case 2:
			printEmpresa(operacionesEmpresa.getEmpresa(getThingy("Nombre de empresa: ")));
			break;
		case 3:
			printEmpleado(operacionesEmpresa.getEmpleado(getThingy("Nombre de empleado: ")));
			break;
		case 4:
			operacionesEmpresa.addEmpresa(getEmpresa());
			break;
		case 5:
			operacionesEmpresa.addEmpresaAutogen(getEmpresaNoID());
			break;
		case 6:
			if (operacionesEmpresa.addEmpleadoAEmpresa(getEmpleado(), getThingy("Nombre de empresa: "))) {
				System.out.println("Empleado añadido.");
			} else {
				System.out.println("Empresa no existe. ");
			}
			break;
		case 7:
			if (operacionesEmpresa.changeEmpleado(getThingy("Nombre Empleado a modificar: "), getEmpleado())) {
				System.out.println("Empleado añadido.");
			} else {
				System.out.println("Empresa no existe. ");
			}
			break;
		case 8:
			if (operacionesEmpresa.deleteEmpleado(getThingy("Nombre del Empleado: "))) {
				System.out.println("Empleado borrado.");
			} else {
				System.out.println("Empleado no existe. ");
			}
			break;
		case 9:
			if (operacionesEmpresa.despedirEmpleado(getThingy("Nombre del Empleado: "))) {
				System.out.println("Empleado despedido.");
			} else {
				System.out.println("Empleado no existe. ");
			}
			break;
		default:
			System.out.println("Invalid option");
		}
	}

	private String getThingy(String text) {
		System.out.print(text);
		return scanner.nextLine().trim();
	}

	private Empresa getEmpresa() {
		Empresa ret = new Empresa();
		ret.setId(getThingy("Id empresa: "));
		ret.setNombre(getThingy("Nombre empresa: "));
		ret.setLocalizacion(getThingy("Localizacion empresa: "));
		return ret;
	}

	private Empresa getEmpresaNoID() {
		Empresa ret = new Empresa();
		ret.setNombre(getThingy("Nombre empresa: "));
		ret.setLocalizacion(getThingy("Localizacion empresa: "));
		return ret;
	}

	private Empleado getEmpleado() {
		Empleado ret = new Empleado();
		ret.setId(getThingy("Id empleado: "));
		ret.setNombre(getThingy("Nombre empleado: "));
		ret.setApellido(getThingy("Apellido empleado: "));
		ret.setDireccion(getThingy("Direccion empleado: "));
		ret.setFecha(getThingy("Fecha empleado: "));
		ret.setSalario(getThingy("Salario empleado: "));
		ret.setComision(getThingy("Comision empleado: "));
		return ret;
	}

	private void printEmpresas(List<Empresa> empresas) {
		for (Empresa empresa : empresas) {
			printEmpresa(empresa);
		}
	}

	private void printEmpresa(Empresa empresa) {
		if (null != empresa)
			System.out.println(empresa.toString());
		else
			System.out.println("No hay documento de Empresa");
	}

	private void printEmpleado(Empleado empleado) {
		if (null != empleado) {
			System.out.println(empleado.toString());
			System.out.print("|---");
			printEmpresa(empleado.getEmpresa());
		} else
			System.out.println("No hay documento de Empleado");
	}
}
