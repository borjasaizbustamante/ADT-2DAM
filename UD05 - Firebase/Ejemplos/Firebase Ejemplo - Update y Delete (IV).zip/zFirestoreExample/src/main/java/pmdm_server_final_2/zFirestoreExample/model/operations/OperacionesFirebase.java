package pmdm_server_final_2.zFirestoreExample.model.operations;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.FieldValue;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;

import pmdm_server_final_2.zFirestoreExample.model.entities.Empleado;
import pmdm_server_final_2.zFirestoreExample.model.entities.Empresa;
import pmdm_server_final_2.zFirestoreExample.model.exceptions.FireBaseException;

/**
 * Clase de operaciones de acceso a BBDD de Firebase. Para que funcione,
 * recuerda que se necesita un fichero de permisos ("/EmpresaBD.json").
 * 
 * Cualquier error de 'No se puede autenticar' puede requerir volver a bajarse
 * el fichero de credenciales
 */
public class OperacionesFirebase implements OperacionesInterface {

	private static final String CREDENTIALS = "/EmpresaBD.json";
	private static final String COLLECTION_EMPRESA = "EmpresaBD";
	private static final String COLLECTION_EMPLEADO = "EmpleadoBD";

	/**
	 * Constructor de la clase. Inicializa FirebaseApp. Esto solo debe de hacerse
	 * una vez, si no da problemas.
	 * 
	 * @throws FireBaseException
	 */
	public OperacionesFirebase() throws FireBaseException {
		try {
			if (FirebaseApp.getApps().isEmpty()) {
				InputStream serviceAccount = OperacionesFirebase.class.getResourceAsStream(CREDENTIALS);
				FirebaseOptions options = FirebaseOptions.builder()
						.setCredentials(GoogleCredentials.fromStream(serviceAccount)).build();
				FirebaseApp.initializeApp(options);
			}
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
	}

	@Override
	public List<Empresa> getEmpresas() throws FireBaseException {
		List<Empresa> ret = null;

		try {

			Firestore dataBase = FirestoreClient.getFirestore();

			// Query...
			ApiFuture<QuerySnapshot> query = dataBase.collection(COLLECTION_EMPRESA).get();

			// Procesamos la query...
			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> empresas = querySnapshot.getDocuments();
			for (QueryDocumentSnapshot empresa : empresas) {
				ret = null == ret ? new ArrayList<Empresa>() : ret;
				ret.add(new Empresa(empresa.getId(), empresa.getString("nombre"), empresa.getString("localizacion")));
			}

			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}

		return ret;
	}

	@Override
	public Empresa getEmpresa(String name) throws FireBaseException {
		Empresa ret = null;
		try {

			Firestore dataBase = FirestoreClient.getFirestore();

			// Query...
			ApiFuture<QuerySnapshot> query = dataBase.collection(COLLECTION_EMPRESA).whereEqualTo("nombre", name).get();

			// Procesamos la query...
			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> empresas = querySnapshot.getDocuments();
			for (QueryDocumentSnapshot empresa : empresas) {
				ret = new Empresa(empresa.getId(), empresa.getString("nombre"), empresa.getString("localizacion"));
				break;
			}

			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

	@Override
	public Empresa getEmpresaByID(String id) throws FireBaseException {
		Empresa ret = null;
		try {

			Firestore dataBase = FirestoreClient.getFirestore();

			// Query...
			DocumentReference documentReference = dataBase.collection(COLLECTION_EMPRESA).document(id);
			DocumentSnapshot documentSnapshot = documentReference.get().get();

			// Procesamos ...
			if (null != documentSnapshot) {
				ret = new Empresa(documentSnapshot.getId(), documentSnapshot.getString("nombre"),
						documentSnapshot.getString("localizacion"));
			}

			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

	@Override
	public Empleado getEmpleado(String name) throws FireBaseException {
		Empleado ret = null;
		try {

			Firestore dataBase = FirestoreClient.getFirestore();

			// Query... para buscar Empleado
			ApiFuture<QuerySnapshot> query = dataBase.collection(COLLECTION_EMPLEADO).whereEqualTo("Nombre", name)
					.get();

			// Procesamos la query...
			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> empleados = querySnapshot.getDocuments();
			for (QueryDocumentSnapshot empleado : empleados) {

				ret = new Empleado(empleado.getString("Nombre"), empleado.getString("Apellido"),
						empleado.getString("Oficio"), empleado.getString("Direccion"), empleado.getString("Fecha"),
						empleado.getString("Salario"), empleado.getString("Comision"), null);

				// Nos falta los datos de la Empresa. Es una referencia que viene con el campo
				// "puesto".
				DocumentReference puestoRef = (DocumentReference) empleado.getData().get("puesto");
				ret.setEmpresa(puestoRef == null ? null : getEmpresaByID(puestoRef.getId()));
				break;
			}

			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

	@Override
	public void addEmpresa(Empresa empresa) throws FireBaseException {
		try {
			Firestore dataBase = FirestoreClient.getFirestore();

			// Query... donde vamos a colocar el documento de empresa
			CollectionReference query = dataBase.collection(COLLECTION_EMPRESA);

			// El Map que representa el documento con sus campos...
			Map<String, Object> empresaMap = new HashMap<>();
			empresaMap.put("nombre", empresa.getNombre());
			empresaMap.put("localizacion", empresa.getLocalizacion());

			// Le cargamos la ID (de Firebase) de forma manual desde Java
			DocumentReference documentReference = query.document(empresa.getId());
			documentReference.set(empresaMap);

			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
	}

	@Override
	public void addEmpresaAutogen(Empresa empresa) throws FireBaseException {
		try {
			Firestore dataBase = FirestoreClient.getFirestore();

			// Query... donde vamos a colocar el documento de empresa
			CollectionReference query = dataBase.collection(COLLECTION_EMPRESA);

			// El Map que representa el documento con sus campos...
			Map<String, Object> empresaMap = new HashMap<>();
			empresaMap.put("nombre", empresa.getNombre());
			empresaMap.put("localizacion", empresa.getLocalizacion());

			// Le cargamos la ID autogenerada por firebase
			DocumentReference documentReference = query.document();
			documentReference.set(empresaMap);

			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
	}

	@Override
	public boolean addEmpleadoAEmpresa(Empleado empleado, String nameEmpresa) throws FireBaseException {
		boolean ret = false;
		try {
			Firestore dataBase = FirestoreClient.getFirestore();

			// La referencia a la empresa...
			ApiFuture<QuerySnapshot> future = dataBase.collection(COLLECTION_EMPRESA)
					.whereEqualTo("nombre", nameEmpresa).get();

			// Procesamos la query...
			QuerySnapshot querySnapshot = future.get();
			List<QueryDocumentSnapshot> empresas = querySnapshot.getDocuments();
			if (!empresas.isEmpty()) {
				// La empresa existe
				ret = true;

				// Referencia a esa empresa...
				DocumentSnapshot documentSnapshot = empresas.get(0);
				DocumentReference empresaReference = documentSnapshot.getReference();

				// -- Preparamos el Documento del Empleado

				// Query... donde vamos a colocar el documento de empresa
				CollectionReference query = dataBase.collection(COLLECTION_EMPLEADO);

				// El Map que representa el documento con sus campos...
				Map<String, Object> empresaMap = new HashMap<>();
				empresaMap.put("Nombre", empleado.getNombre());
				empresaMap.put("Apellido", empleado.getApellido());
				empresaMap.put("Direccion", empleado.getDireccion());
				empresaMap.put("Fecha", empleado.getFecha());
				empresaMap.put("Salario", empleado.getSalario());
				empresaMap.put("Comision", empleado.getComision());
				empresaMap.put("puesto", empresaReference);

				// Le cargamos la ID (de Firebase) de forma manual desde Java
				DocumentReference documentReference = query.document(empleado.getId());
				documentReference.set(empresaMap);

			} else {
				// La empresa no existe
				ret = false;
			}

			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

	@Override
	public boolean changeEmpleado(String nombre, Empleado empleadoNuevo) throws FireBaseException {
		boolean ret = false;
		try {

			Firestore dataBase = FirestoreClient.getFirestore();

			// Query...
			ApiFuture<QuerySnapshot> query = dataBase.collection(COLLECTION_EMPLEADO).whereEqualTo("Nombre", nombre)
					.get();

			// Procesamos la query...
			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> empleados = querySnapshot.getDocuments();
			if (!empleados.isEmpty()) {

				// Referencia a ese empleado...
				DocumentSnapshot documentSnapshot = empleados.get(0);
				DocumentReference empleadoReference = documentSnapshot.getReference();

				// El Map que representa el documento con sus campos...
				Map<String, Object> empleadoMap = new HashMap<>();
				empleadoMap.put("Nombre", empleadoNuevo.getNombre());
				empleadoMap.put("Apellido", empleadoNuevo.getApellido());
				empleadoMap.put("Direccion", empleadoNuevo.getDireccion());
				empleadoMap.put("Fecha", empleadoNuevo.getFecha());
				empleadoMap.put("Salario", empleadoNuevo.getSalario());
				empleadoMap.put("Comision", empleadoNuevo.getComision());

				// Actualizamos...
				empleadoReference.update(empleadoMap);
				ret = true;
			}

			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

	@Override
	public boolean deleteEmpleado(String nombre) throws FireBaseException {
		boolean ret = false;
		try {

			Firestore dataBase = FirestoreClient.getFirestore();

			// Query...
			ApiFuture<QuerySnapshot> query = dataBase.collection(COLLECTION_EMPLEADO).whereEqualTo("Nombre", nombre)
					.get();

			// Procesamos la query...
			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> empleados = querySnapshot.getDocuments();
			if (!empleados.isEmpty()) {

				// Referencia a ese empleado...
				DocumentSnapshot documentSnapshot = empleados.get(0);
				DocumentReference empleadoReference = documentSnapshot.getReference();

				// Actualizamos...
				empleadoReference.delete();
				ret = true;
			}
			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

	public boolean despedirEmpleado(String nombre) throws FireBaseException {
		boolean ret = false;
		try {

			Firestore dataBase = FirestoreClient.getFirestore();

			// Query...
			ApiFuture<QuerySnapshot> query = dataBase.collection(COLLECTION_EMPLEADO).whereEqualTo("Nombre", nombre)
					.get();

			// Procesamos la query...
			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> empleados = querySnapshot.getDocuments();
			if (!empleados.isEmpty()) {

				// Referencia a ese empleado...
				DocumentSnapshot documentSnapshot = empleados.get(0);
				DocumentReference empleadoReference = documentSnapshot.getReference();

				// El Map que representa el documento con sus campos...
				Map<String, Object> empleadoMap = new HashMap<>();
				empleadoMap.put("puesto", FieldValue.delete());

				// Actualizamos...
				empleadoReference.update(empleadoMap);
				ret = true;
			}
			dataBase.close();
		} catch (Exception e) {
			throw new FireBaseException("Error - " + e.getLocalizedMessage());
		}
		return ret;
	}

}
